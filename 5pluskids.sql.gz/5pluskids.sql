-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 05 2018 г., 19:16
-- Версия сервера: 5.7.17
-- Версия PHP: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `5pluskids`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cms_email_queue`
--

CREATE TABLE `cms_email_queue` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID записи',
  `template_html` varchar(50) NOT NULL COMMENT 'HTML-шаблон',
  `template_text` varchar(50) NOT NULL COMMENT 'Текстовый шаблон',
  `params` text COMMENT 'Параметры для передачи в шаблон',
  `sender` varchar(255) NOT NULL COMMENT 'Отправитель',
  `recipient` varchar(255) NOT NULL COMMENT 'Получатель',
  `subject` varchar(255) NOT NULL COMMENT 'Тема',
  `state` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Статус отправки',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Дата добавления',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Дата обновления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_errors`
--

CREATE TABLE `cms_errors` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `module` varchar(255) NOT NULL COMMENT 'Место ошибки',
  `content` text NOT NULL COMMENT 'Содержимое ошибки',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module`
--

CREATE TABLE `cms_module` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `controller` char(50) DEFAULT NULL,
  `action` char(50) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `url_prefix` varchar(50) DEFAULT NULL COMMENT 'Префикс URL',
  `field_for_url` varchar(50) DEFAULT NULL COMMENT 'Поле, которое использовать для генерации URL',
  `field_for_title` varchar(50) DEFAULT NULL COMMENT 'Поле, из которого скопировать Title',
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `cms_module`
--

INSERT INTO `cms_module` (`id`, `controller`, `action`, `description`, `url_prefix`, `field_for_url`, `field_for_title`, `active`) VALUES
(1, 'page', 'view', 'Отображение статичных страниц', NULL, 'page-title', 'page-title', 1),
(2, 'subject', 'index', 'Список курсов', NULL, NULL, NULL, 1),
(3, 'subject', 'view', 'Страница курса', 'subject/', 'subject-name', 'subject-name', 1),
(4, 'review', 'index', 'Страница отзывов', NULL, NULL, NULL, 1),
(5, 'teacher', 'index', 'Страница со списком учителей', NULL, NULL, NULL, 1),
(6, 'teacher', 'view', 'Страница учителя', 'teacher/', 'teacher-name', 'teacher-name', 1),
(27, 'subject-age', 'index', 'Список курсов по возрасту', NULL, NULL, NULL, 1),
(28, 'subject-age', 'view', 'Страница курса по возрасту', 'subject-age/', 'subjectage-name', 'subjectage-name', 1),
(29, 'news', 'index', 'Страница новостей', NULL, NULL, NULL, 1),
(30, 'news', 'view', 'Страница одной новости', 'news/', 'news-name', 'news-name', 1),
(31, 'promotion', 'index', 'Страница акций', NULL, NULL, NULL, 1),
(32, 'promotion', 'view', 'Страница одной акции', 'promotion/', 'promotion-name', 'promotion-name', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_feedback`
--

CREATE TABLE `cms_module_feedback` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID сообщения',
  `name` varchar(50) NOT NULL COMMENT 'Имя пользователя',
  `contact` varchar(255) NOT NULL COMMENT 'Как с ним связаться',
  `message` text NOT NULL COMMENT 'Сообщение',
  `status` enum('new','read','completed') NOT NULL DEFAULT 'new' COMMENT 'Статус',
  `ip` varchar(40) NOT NULL COMMENT 'IP адрес отправителя',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_news`
--

CREATE TABLE `cms_module_news` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID новости',
  `name` varchar(50) NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) DEFAULT NULL COMMENT 'Картинка',
  `content` text NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата новости'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_order`
--

CREATE TABLE `cms_module_order` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `subject` varchar(127) NOT NULL COMMENT 'Предмет',
  `name` varchar(50) NOT NULL COMMENT 'Имя',
  `phone` char(13) NOT NULL COMMENT 'Телефон',
  `status` enum('unread','read','done','problem') NOT NULL DEFAULT 'unread' COMMENT 'Статус заявки',
  `user_comment` varchar(255) DEFAULT NULL COMMENT 'Комментарии от заказчика',
  `admin_comment` varchar(255) DEFAULT NULL COMMENT 'Комментарии админа',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата подачи'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_page`
--

CREATE TABLE `cms_module_page` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID',
  `title` varchar(255) NOT NULL COMMENT 'Заголовок',
  `content` text NOT NULL COMMENT 'Содержимое',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'ID webpage',
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'активна',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_promotions`
--

CREATE TABLE `cms_module_promotions` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID акции',
  `name` varchar(50) NOT NULL COMMENT 'Заголовок',
  `image` varchar(255) DEFAULT NULL COMMENT 'Картинка',
  `content` text NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата акции'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_review`
--

CREATE TABLE `cms_module_review` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID отзыва',
  `name` varchar(50) NOT NULL COMMENT 'Имя автора',
  `message` varchar(1000) NOT NULL COMMENT 'Текст отзыва',
  `status` enum('new','approved') NOT NULL DEFAULT 'new' COMMENT 'Статус отзыва',
  `ip` varchar(40) NOT NULL COMMENT 'IP адрес отправителя',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата добавления'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_subject`
--

CREATE TABLE `cms_module_subject` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(50) NOT NULL COMMENT 'Название курса',
  `icon` varchar(255) DEFAULT NULL COMMENT 'Иконка для виджета',
  `image` varchar(255) DEFAULT NULL COMMENT 'Картинка',
  `description` text NOT NULL COMMENT 'Тизер',
  `content` text NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `page_order` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Позиция в списке'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_subject_age`
--

CREATE TABLE `cms_module_subject_age` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID предмета',
  `name` varchar(50) NOT NULL COMMENT 'Название курса',
  `icon` varchar(255) DEFAULT NULL COMMENT 'Иконка для виджета',
  `image` varchar(255) DEFAULT NULL COMMENT 'Картинка',
  `description` text NOT NULL COMMENT 'Тизер',
  `content` text NOT NULL COMMENT 'Контент',
  `webpage_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'ID страницы',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Активен',
  `page_order` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Позиция в списке'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_module_teacher`
--

CREATE TABLE `cms_module_teacher` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'ID учителя',
  `name` varchar(127) NOT NULL COMMENT 'ФИО',
  `title` varchar(255) NOT NULL COMMENT 'Специализация учителя',
  `description` text NOT NULL COMMENT 'Текст об учителе',
  `photo` varchar(255) DEFAULT NULL COMMENT 'Фото',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Страничка',
  `active` tinyint(4) DEFAULT '1' COMMENT 'Активен',
  `page_order` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядок отображения на странице учителей'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_tinified`
--

CREATE TABLE `cms_tinified` (
  `fileName` varchar(127) NOT NULL,
  `checksum` char(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_user`
--

CREATE TABLE `cms_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(127) NOT NULL,
  `name` varchar(127) NOT NULL COMMENT 'Имя пользователя',
  `auth_key` varchar(32) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `password_reset_token` varchar(127) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `role` tinyint(4) NOT NULL COMMENT 'Уровень доступа пользователя',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Дата добавления',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата изменения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_webpage`
--

CREATE TABLE `cms_webpage` (
  `id` int(11) UNSIGNED NOT NULL,
  `url` char(255) NOT NULL DEFAULT '',
  `main` tinyint(1) UNSIGNED DEFAULT NULL,
  `title` char(255) DEFAULT NULL,
  `description` text,
  `keywords` text,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `module_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `record_id` int(11) UNSIGNED DEFAULT NULL,
  `inrobots` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_widget_html`
--

CREATE TABLE `cms_widget_html` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `editor` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Визуальный редактор'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_widget_menu`
--

CREATE TABLE `cms_widget_menu` (
  `id` tinyint(3) UNSIGNED NOT NULL COMMENT 'ID',
  `name` varchar(63) NOT NULL COMMENT 'Название меню',
  `title` varchar(255) DEFAULT NULL COMMENT 'Заголовок меню'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `cms_widget_menu_item`
--

CREATE TABLE `cms_widget_menu_item` (
  `id` int(11) UNSIGNED NOT NULL COMMENT 'ID',
  `menu_id` tinyint(3) UNSIGNED NOT NULL COMMENT 'Меню',
  `parent_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Родительский пункт меню',
  `webpage_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Ссылка на страницу сайта',
  `url` varchar(255) DEFAULT NULL COMMENT 'URL',
  `title` varchar(127) DEFAULT NULL COMMENT 'Текст пункта меню',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'Показывать или нет',
  `attr` text COMMENT 'Доп параметры',
  `orderby` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Порядок'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cms_email_queue`
--
ALTER TABLE `cms_email_queue`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_errors`
--
ALTER TABLE `cms_errors`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_module`
--
ALTER TABLE `cms_module`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `module_ukey` (`controller`,`action`);

--
-- Индексы таблицы `cms_module_feedback`
--
ALTER TABLE `cms_module_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip` (`ip`);

--
-- Индексы таблицы `cms_module_news`
--
ALTER TABLE `cms_module_news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_module_news_ibfk_3` (`webpage_id`);

--
-- Индексы таблицы `cms_module_order`
--
ALTER TABLE `cms_module_order`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_module_page`
--
ALTER TABLE `cms_module_page`
  ADD PRIMARY KEY (`id`),
  ADD KEY `page_webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_module_promotions`
--
ALTER TABLE `cms_module_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_module_promotions_ibfk_3` (`webpage_id`) USING BTREE;

--
-- Индексы таблицы `cms_module_review`
--
ALTER TABLE `cms_module_review`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_module_subject`
--
ALTER TABLE `cms_module_subject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_module_subject_age`
--
ALTER TABLE `cms_module_subject_age`
  ADD PRIMARY KEY (`id`),
  ADD KEY `webpage_id` (`webpage_id`);

--
-- Индексы таблицы `cms_module_teacher`
--
ALTER TABLE `cms_module_teacher`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_module_teacher_title_index` (`title`);

--
-- Индексы таблицы `cms_tinified`
--
ALTER TABLE `cms_tinified`
  ADD PRIMARY KEY (`fileName`);

--
-- Индексы таблицы `cms_user`
--
ALTER TABLE `cms_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- Индексы таблицы `cms_webpage`
--
ALTER TABLE `cms_webpage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `webpage_uk` (`url`),
  ADD KEY `webpage_module_language` (`module_id`);

--
-- Индексы таблицы `cms_widget_html`
--
ALTER TABLE `cms_widget_html`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cms_widget_html_name_uindex` (`name`);

--
-- Индексы таблицы `cms_widget_menu`
--
ALTER TABLE `cms_widget_menu`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `cms_widget_menu_item`
--
ALTER TABLE `cms_widget_menu_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_item_menu_id` (`menu_id`),
  ADD KEY `menu_item_parent_id` (`parent_id`),
  ADD KEY `menu_item_webpage_id` (`webpage_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cms_email_queue`
--
ALTER TABLE `cms_email_queue`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID записи', AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT для таблицы `cms_errors`
--
ALTER TABLE `cms_errors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT для таблицы `cms_module`
--
ALTER TABLE `cms_module`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT для таблицы `cms_module_feedback`
--
ALTER TABLE `cms_module_feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID сообщения', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `cms_module_news`
--
ALTER TABLE `cms_module_news`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID новости', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `cms_module_order`
--
ALTER TABLE `cms_module_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `cms_module_page`
--
ALTER TABLE `cms_module_page`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `cms_module_promotions`
--
ALTER TABLE `cms_module_promotions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID акции', AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `cms_module_review`
--
ALTER TABLE `cms_module_review`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID отзыва', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `cms_module_subject`
--
ALTER TABLE `cms_module_subject`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID предмета', AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT для таблицы `cms_module_subject_age`
--
ALTER TABLE `cms_module_subject_age`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID предмета', AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `cms_module_teacher`
--
ALTER TABLE `cms_module_teacher`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID учителя', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `cms_user`
--
ALTER TABLE `cms_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;
--
-- AUTO_INCREMENT для таблицы `cms_webpage`
--
ALTER TABLE `cms_webpage`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT для таблицы `cms_widget_html`
--
ALTER TABLE `cms_widget_html`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `cms_widget_menu`
--
ALTER TABLE `cms_widget_menu`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `cms_widget_menu_item`
--
ALTER TABLE `cms_widget_menu_item`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=3;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cms_module_news`
--
ALTER TABLE `cms_module_news`
  ADD CONSTRAINT `cms_module_news_ibfk_3` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_page`
--
ALTER TABLE `cms_module_page`
  ADD CONSTRAINT `cms_module_page_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_promotions`
--
ALTER TABLE `cms_module_promotions`
  ADD CONSTRAINT `cms_module_promotions_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_subject`
--
ALTER TABLE `cms_module_subject`
  ADD CONSTRAINT `cms_module_subject_ibfk_3` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_module_subject_age`
--
ALTER TABLE `cms_module_subject_age`
  ADD CONSTRAINT `cms_module_subject_age_ibfk_3` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `cms_widget_menu_item`
--
ALTER TABLE `cms_widget_menu_item`
  ADD CONSTRAINT `cms_widget_menu_item_ibfk_1` FOREIGN KEY (`webpage_id`) REFERENCES `cms_webpage` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
